from statemachine import StateMachine

class TabletTouchBaseStateMachine(StateMachine):
    def Touch_EvDevY__Input_GetInputEvent(self,event):
        "B"
        return self.hdwy == event.e2

    def Input_GetInputEvent__Input_PrepareDispatchMotion(self,event):
        "C"
        self.x = event.e1
        self.y = event.e2
        return True

    def Input_PrepareDispatchMotion__Input_InputQueueJni(self,event):
        "D"
        return self.x == event.e1 and self.y == event.e2

    def Input_InputQueueJni__InputQueueJava_MotionEvent(self,event):
        "E"
        return self.x == event.e1 and self.y == event.e2

    def InputQueueJava_MotionEvent__ViewSubSystem_TouchEvent(self,event):
        "F"
        return self.x == event.e1 and self.y == event.e2

    def ViewSubSystem_TouchEvent__SurfaceFlinger_SetupHWCTouch(self,event):
        "G"
        return self.x == event.e1 and self.y == event.e2

    def SurfaceFlinger_SetupHWCTouch__HardwareComposer_HwcPrepare(self,event):
        "H"
        self.syncid = event.e1
        return True

    def HardwareComposer_HwcPrepare__DssDriver_DssCompGrallocQueueLogAddr(self,event):
        "I"
        self.grallocaddr = event.e2
        return self.syncid == event.e1

    def DssDriver_DssCompGrallocQueueLogAddr__DssDriver_DssCompApplyLogAddr(self,event):
        "J"
        self.paddr = event.e2
        return self.grallocaddr == event.e1

    def DssDriver_DssCompApplyLogAddr__DssDriver_DssCompGrallocCallback(self,event):
        "K"
        return self.grallocaddr == event.e1

    def DssDriver_DssCompGrallocCallback__DssDriver_DispcSetupPlane(self,event):
        "L"
        self.plane = event.e1
        return self.paddr == event.e2

    def DssDriver_DispcSetupPlane__DssDriver_DssIrqHandler(self,event):
        "M"
        return StateMachine.FINISHED

