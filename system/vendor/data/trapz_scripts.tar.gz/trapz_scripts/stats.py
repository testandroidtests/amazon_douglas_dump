#!/usr/bin/python

import sys
from trapztool import *

try:
    import numpy as np
except ImportError:
    sys.stderr.write("This script requires SciPy package\n")
    sys.stderr.write("Ubuntu: sudo apt-get install python-scipy\n")
    sys.stderr.write("Other platforms: see http://www.scipy.org/Installing_SciPy\n")
    sys.exit(1)

try:
    import matplotlib.pyplot as plot
except ImportError:
    sys.stderr.write("This script requires matplotlib package\n")
    sys.stderr.write("Ubuntu: sudo apt-get install python-matplotlib\n")
    sys.stderr.write("Other platforms: see http://matplotlib.sourceforge.net/\n")
    sys.exit(1)


VERSION = '0.1'

"""
This is an example of a simple Python script which uses trapztool,
along with the SciPy/NumPy/Matplotlib suite, to generate a histogram
of the durations of a particular scope event in the Trapz log.

./stats.py --help for usage
"""
try:
    # We're using the argument parsing library argparse. This is in the
    # Python 2.7 standard library, and is also available as a
    # compatibility library for previous versions.
    import argparse
except ImportError:
    # If neither of these are installed, we will use our own local
    # copy which is in labscripts/trapz/argparse/argparse.py
    sys.path.append(os.path.join(sys.path[0],'argparse'))
    import argparse

class TrapzXmlFilter(TrapzXmlValidator):

    def FilterEvents(self, cat, comp, trace, tid=None):
        """returns only events from a given trace"""
        return [e for e in self.events if
                e.category == cat and e.compId == comp and
                e.traceId == trace and (tid is None or e.tid == tid)]

    @classmethod
    def Intervals(cls, events):
        """converts a list of Trapz events into intervals: (startTime, duration)

        for scope traces, interval is from enter to exit
        for other traces, interval is from one event to next"""
        events.sort() # just to be sure
        offset = events[0].timestamp
        prevTime = None
        intervals = []
        # see if this is a scope trace
        e2values = set([e.e2 for e in events])
        if e2values.issubset(set([-1, 0, 1])) and len(e2values) > 1:
            for e in events:
                eTime = float(e.timestamp - offset) * 1000. # milliseconds
                if e.e2 == 1:
                    prevTime = eTime
                else:
                    if prevTime:
                        intervals.append((prevTime, eTime - prevTime))
                        prevTime = None
        else:
            for e in events:
                eTime = float(e.timestamp - offset) * 1000. # milliseconds
                if prevTime:
                    intervals.append((prevTime, eTime - prevTime))
                prevTime = eTime

        return np.array(intervals)

    @classmethod
    def Histogram(cls, intervals):
        (hist,bins) = np.histogram(intervals[:,1], bins=50)
        center=(bins[:-1]+bins[1:])/2
        width=0.7*(bins[1]-bins[0])
        plot.bar(center,hist,align='center',width=width)
        plot.xlabel('milliseconds')
        plot.ylabel('count')
        plot.title('Histogram of Event Intervals')
        plot.show()

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='TRAPZ statistics tool')
    parser.add_argument('-v', '--version', action='version', version='%%(prog)s %s' % VERSION)
    parser.add_argument('--category', help='ID of component', type=int, required=True)
    parser.add_argument('--component', help='ID of component', type=int, required=True)
    parser.add_argument('--trace', help='ID of trace', type=int, required=True)
    parser.add_argument('--tid', help='thread ID to filter for', type=int)
    #group = parser.add_mutually_exclusive_group()
    #group.add_argument('--interval', help='measure time interval between events (disable autodetect)', action='store_true')
    #group.add_argument('--scope', help='measure scope (disable autodetect)', action='store_true')
    parser.add_argument('trapzfile', nargs='?', type=argparse.FileType('r'),
                           default=sys.stdin, help='filename of TRAPZ XML trace file')
    # parse the command line
    args = parser.parse_args()

    # Create XML parser + VCD helper class
    xml = TrapzXmlFilter()
    xml.Parse(args.trapzfile)
    events = xml.FilterEvents(args.category, args.component, args.trace, args.tid)
    #intervals = xml.Intervals(events, args.interval, args.scope)
    intervals = xml.Intervals(events)
    xml.Histogram(intervals)
